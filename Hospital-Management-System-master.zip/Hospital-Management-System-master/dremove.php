<html>
<head>


    <title>table</title>


    <title>Example form</title>
    <style type="text/css">
        .container {
            width: 250px;
            clear: both;
        }
        .container input {
            width: 100%;
            clear: both;
        }

    </style>

</head>

<body>


    <table border="5px" align="center" width="1000px" cellspacing="2px">
        <tr align="center" bgcolor="white" height="100px"><td colspan=6>IIT-MANDI HOSPITAL</td></tr>
        <tr  height="300px" bgcolor="pink"><td colspan=6 background="b3.jpg">

            <div align="center"><b>RECORDS</b>

                <br><br>


                <div class = "container">

                   <form method="post" action="enterrecord.php" name="myform">

                    <div align="center"><font color="black"><b><b><b><b><b>Enter Details:</b></b></b></b></b></font><br><br>

                        <font color="black"><b><b><b><b><b>PATIENT USERNAME:</b></b></b></b></b> </font>
                        <?php
    $conn = mysqli_connect('localhost','root','qwerty','hospital');
    if(!$conn)
        die("Connection failed!<br>".mysqli_connect_error());
    $cookiename = md5('p');
    if(isset($_COOKIE[$cookiename])){
        $username = $_COOKIE['username'];
        $query = "select * from patient where pusername = '$username'";
        $result = mysqli_query($conn,$query);
        while($row = mysqli_fetch_assoc($result))
            $pusername = $row['pusername'];
        $query = "SELECT dusername FROM pdmap where pdmap.pusername = '$pusername'";
        $result = mysqli_query($conn,$query);
        echo "<select name='dusername'>";
        while ($row = mysqli_fetch_assoc($result))
            echo "<option value='" . $row['dusername'] . "'>" . $row['dusername'] . "</option>";
        echo "</select><br>(No option signifies you don't have any Doctor assigned to you)<br>";
    }
    ?>



                        




                        
                        <br></div></div>
                        <input type="submit" name="submit" value="submit"/>
                        <input type="reset" name="reset" value="reset"/>


                    </form>

                </td>
            </tr>
            <tr bgcolor="white" height="50px"><td colspan=6><div align="center">
            </div>
        </td>
    </tr>
    <br>
</table>
</body>
</html>i
