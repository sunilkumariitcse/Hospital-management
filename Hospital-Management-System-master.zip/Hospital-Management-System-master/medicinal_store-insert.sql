insert into Medicinal_stores 
		values('Anacin','050712','090813','15')
insert into Medicinal_stores 
		values('Cofex','030811','060908','35')	
insert into Medicinal_stores 
		values('Crocin','040607','070304','15')	
insert into Medicinal_stores 
		values('Glycodin','050903','070908','30')	
insert into Medicinal_stores 
		values('Mytoxin','051203','080902','45')