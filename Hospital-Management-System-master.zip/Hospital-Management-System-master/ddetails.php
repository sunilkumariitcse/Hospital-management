<!DOCTYPE html>
<html>
<head>
	<title>table</title>
</head>
<body background="2.jpg">
	<table border="5px" align="center" width="600" cellspacing="1" cellpadding="1">
		<tr>
			<th>Doctor Id</th>
			<th>Doctor UserName</th>
			<th>Doctor Name</th>
			<th>DDOB</th>
			<th>DSEX</th>
			<th>Daddress</th>
			<th>Dcontact</th>
			<th>Demail</th>
			<th>Dqual</th>
		</tr>
		<?php
		$conn = mysqli_connect('localhost','root','qwerty','hospital');
		if(!$conn)
			die("Connection failed!<br>".mysqli_connect_error());
		$cookiename = md5('d');
		if(isset($_COOKIE[$cookiename])){
			$username = $_COOKIE['username'];
			$query = "select * from doctor where dusername = '$username'";
			$result = mysqli_query($conn,$query);
			while($row = mysqli_fetch_assoc($result)){
				echo "<tr>";
				echo "<td>".$row['did']."</td>";
				echo "<td>".$row['dusername']."</td>";
				echo "<td>".$row['dfname']." ".$row['dmname']." ".$row['dlname']."</td>";
				echo "<td>".$row['ddob']."</td>";
				echo "<td>".$row['dsex']."</td>";
				echo "<td>".$row['daddress']."</td>";
				echo "<td>".$row['dcontact']."</td>";
				echo "<td>".$row['demail']."</td>";
				echo "<td>".$row['dqualification']."</td>";
				echo "</tr>";
			}
		}
		else{
			echo "YOU HAVE BEEN LOGGED OUT.<br>Redirecting you back to Login Page.";
			echo "<meta http-equiv=\"refresh\" content=\"5;URL=login.html\" />";
		}	
		?>
		</table>
	</body>
	</html>
