insert into department_information
		values('E-1','ENT','Seema Singh','2273578')
insert into department_information
		values('C-2','Cardiology','Rajesh Bhat','2534280')
insert into department_information
		values('G-3','General','Neeraj Shet','2278631')
insert into department_information
		values('P-4','Physiotherapy','Sumeet Pai','2715191')
insert into department_information
		values('E-5','ENT','Karan Sharma','2735467')